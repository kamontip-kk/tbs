package main

import (
	"app/sms"
	"fmt"
)

func main() {

	s := sms.Sms{
		ApiKey:       "",
		ApiSecretKey: "",
		Api:          "",
	}
	res, err := s.Send()
	if err != nil {
		fmt.Print(err)
		return
	}

	if res.StatusCode == 201 {
		fmt.Print("Success ", res.Data)
	} else {
		fmt.Print("Error ", res.Error)
	}

}
