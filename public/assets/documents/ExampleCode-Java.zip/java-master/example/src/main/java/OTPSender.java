import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.*;
import okhttp3.*;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.Base64;
import java.util.Objects;


public class OTPSender {

    static OkHttpClient client = new OkHttpClient().newBuilder().build();
    public static final MediaType mediaType = MediaType.parse("application/json");
    private static  final String url = "https://otp.thaibulksms.com/v1/otp/request";


    @NotNull
    static String sendOtp(String json, String basicAuth) throws IOException {
        RequestBody body = RequestBody.create( json,mediaType);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .addHeader("Authorization", basicAuth)
                .addHeader("Content-Type", "application/json")
                .build();
        try (Response response = client.newCall(request).execute()) {
            return Objects.requireNonNull(response.body()).string();
        }}



    public static String createBasicAuth(OTPStructure header){

        String secret = header.getApiKey() + ":" + header.getApiSecret();
        return "Basic " + Base64.getEncoder().encodeToString(secret.getBytes());

    }

    public static String createRequestBody(OTPStructure message) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(message);
    }

    public static void main(String[] args) throws IOException {
        OTPStructure message = new OTPStructure("%PHONE_NUMBER%","%API_KEY%","%API_SECRET%");
        String auth = createBasicAuth(message);
        String json = createRequestBody(message);
        String response = sendOtp(json, auth);
        System.out.println(response);
    }
}

