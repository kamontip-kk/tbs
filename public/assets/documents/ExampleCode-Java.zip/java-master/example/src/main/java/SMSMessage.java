public class SMSMessage {

    private String message;
    private String msisdn;
    private String apiKey;
    private String apiSecret;
    private String sender;
    private String force;
    private String scheduled_delivery;

    public SMSMessage(String msisdn,String message, String apiKey,
                      String apiSecret, String sender,
                      String scheduled_delivery,String force) {
        this.message = message;
        this.msisdn = msisdn;
        this.apiKey = apiKey;
        this.apiSecret = apiSecret;
        this.sender = sender; // optional
        this.scheduled_delivery = scheduled_delivery; // optional
        this.force = force; // optional
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getApiKey() {
        return apiKey;
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

    public String getApiSecret() {
        return apiSecret;
    }

    public void setApiSecret(String apiSecret) {
        this.apiSecret = apiSecret;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getForce() {
        return force;
    }

    public void setForce(String force) {
        this.force = force;
    }

    public String getScheduled_delivery() {
        return scheduled_delivery;
    }

    public void setScheduled_delivery(String scheduled_delivery) {
        this.scheduled_delivery = scheduled_delivery;
    }
};