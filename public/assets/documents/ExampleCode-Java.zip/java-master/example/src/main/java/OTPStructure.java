public class OTPStructure {

    private String msisdn;
    private String apiKey;
    private String apiSecret;
    private String token;
    private String pin;

    public OTPStructure(String msisdn, String apiKey,
                        String apiSecret) {
        this.msisdn = msisdn;
        this.apiKey = apiKey;
        this.apiSecret = apiSecret;
    }

    public OTPStructure(String apiKey,
                        String apiSecret,String token, String pin) {
        this.apiKey = apiKey;
        this.apiSecret = apiSecret;
        this.apiKey = apiKey;
        this.apiSecret = apiSecret;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getApiKey() {
        return apiKey;
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

    public String getApiSecret() {
        return apiSecret;
    }

    public void setApiSecret(String apiSecret) {
        this.apiSecret = apiSecret;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }
};