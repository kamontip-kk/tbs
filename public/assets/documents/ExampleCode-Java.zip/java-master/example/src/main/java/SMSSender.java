import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.*;
import okhttp3.*;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.Base64;
import java.util.Objects;


public class SMSSender {

    static OkHttpClient client = new OkHttpClient().newBuilder().build();
    public static final MediaType mediaType = MediaType.parse("application/json");
    private static  final String url = "https://api-v2.thaibulksms.com/sms";

    @NotNull
    static String sendSMS(String json, String basicAuth) throws IOException {
        RequestBody body = RequestBody.create( json,mediaType);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .addHeader("Authorization", basicAuth)
                .addHeader("Content-Type", "application/json")
                .build();
        try (Response response = client.newCall(request).execute()) {
            return Objects.requireNonNull(response.body()).string();
        }}



    public static String createBasicAuth(SMSMessage message){

        String secret = message.getApiKey() + ":" + message.getApiSecret();
        return "Basic " + Base64.getEncoder().encodeToString(secret.getBytes());

    }

    public static String createRequestBody(SMSMessage message) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(message);


    }

    public static void main(String[] args) throws IOException {
        SMSMessage message = new SMSMessage("%PHONE_NUMBER%",
                "%MESSAGE%","%API_KEY%","%SECRET_KEY%",
                "%SENDER_NAME || NULL%","%SCHEDULED_DELIVERY || NULL%",
                "%CORPORATE || NULL%");
        String auth = createBasicAuth(message);
        String json = createRequestBody(message);
        String response = sendSMS(json, auth);
        System.out.println(response);
    }
}
