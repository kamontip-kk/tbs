#!/usr/bin/env python
import json
from thaibulksms_api import sms

api_key = ""
api_secre_key = ""
phone_number = ""
message = "Hello Thaibulksms"
response = sms.send_sms(api_key, api_secre_key, phone_number, message)
# sms.send_sms(api_key, api_secre_key, phone_number, message, sendername, scheduled_delivery, force)
# API reference https://developer.thaibulksms.com/reference#sms-2

if response.status_code == 201:
    print("Success", response.json())

else:
    print("Error", response.json()['error'])
