#
#  Created by Patipol Treerojporn on 30/04/12
#  Copyright (c) 2555 1Moby Co., Ltd. All rights reserved.
#

import sys, os
sys.path.append(os.path.dirname(__file__))

import types
from xml.dom.minidom import parse, parseString

import web
from web import form
render = web.template.render(os.path.join(os.path.dirname(__file__), 'templates/'))

import ThaiBulkSMSAPI

urls = (
    '/', 'index',
    '/send_message', 'send_message',
    '/get_credit_remain', 'get_credit_remain',
)

sendMessageForm = form.Form(
    form.Textbox('username'),
    form.Textbox('password'),
    form.Textbox('msisdn'),
    form.Textbox('message'),
    form.Textbox('sender'),
    form.Textbox('ScheduledDelivery'),
    form.Button('Send Message'),
    )

getCreditRemainForm = form.Form(
    form.Textbox('username'),
    form.Textbox('password'),
    form.Textbox('tag'),
    form.Button('Get Credit Remain'),
    )

class index:
    def GET(self):
        return render.index()

class send_message:
    def GET(self):
        form = sendMessageForm();
        return render.example_form(form)
    def POST(self):
        form = sendMessageForm();
        if not form.validates(): 
            return render.example_form(form)
        else:
            thaiBulkSMSAPI = ThaiBulkSMSAPI.ThaiBulkSMSAPI()
            result = thaiBulkSMSAPI.sendMessage(form.d.username, form.d.password, form.d.msisdn, form.d.message, form.d.sender, form.d.ScheduledDelivery)
            if result[0] == 200:
                try:
                    dom = parseString(result[1])
                    queue = dom.getElementsByTagName("QUEUE")
                    if len(queue) > 0:
                        count_pass = 0
                        count_fail = 0
                        used_credit = 0
                        for i in range(len(queue)):
                            if queue[i].getElementsByTagName("Status")[0].childNodes[0].nodeValue == "1":
                                count_pass = count_pass+1
                                used_credit = used_credit+int(queue[i].getElementsByTagName("UsedCredit")[0].childNodes[0].nodeValue)
                            else:
                                count_fail = count_fail+1
                        successString = ""
                        if count_pass > 0:
                            successString = "Success: %i message(s), Total: %i credit(s)" % (count_pass, used_credit)
                        failString = ""
                        if count_fail > 0:
                            failString = "Fail: %i message(s)" % (count_fail)
                        return "%s\n%s" % (successString, failString)
                    else:
                        status = dom.getElementsByTagName("Status")[0].childNodes[0].nodeValue
                        detail = dom.getElementsByTagName("Detail")[0].childNodes[0].nodeValue
                        return "Status: %s\nDetail: %s" % (status, detail)
                except:
                    return "Cannot parse XML"
            else:
                return "Error: %i %s" % (result[0], result[1])


class get_credit_remain:
    def GET(self):
        form = getCreditRemainForm();
        return render.example_form(form)
    def POST(self): 
        form = getCreditRemainForm() 
        if not form.validates(): 
            return render.example_form(form)
        else:
            thaiBulkSMSAPI = ThaiBulkSMSAPI.ThaiBulkSMSAPI()
            result = thaiBulkSMSAPI.getCreditRemain(form.d.username, form.d.password, form.d.tag)
            if result[0] == 200:
                if result[1].isdigit():
                    return "Remain Credit(s): %s" % result[1]
                else:
                    try:
                        dom = parseString(result[1])
                        status = dom.getElementsByTagName("Status")[0].childNodes[0].nodeValue
                        detail = dom.getElementsByTagName("Detail")[0].childNodes[0].nodeValue
                        return "Status: %s\nDetail: %s" % (status, detail)
                    except:
                        return "Cannot parse XML"
            else:
                return "Error: %i %s" % (result[0], result[1])

application = web.application(urls, globals()).wsgifunc()
