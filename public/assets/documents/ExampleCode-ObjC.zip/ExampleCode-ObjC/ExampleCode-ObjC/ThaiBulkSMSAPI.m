//
//  ThaiBulkSMSAPI.m
//  TBSAPIObjectiveC
//
//  Created by 1Moby 1Moby on 4/18/55 BE.
//  Copyright (c) 2555 1Moby. All rights reserved.
//

#import "ThaiBulkSMSAPI.h"

@implementation ThaiBulkSMSAPI

@synthesize urlConnectionSendMessage, urlConnectionGetCreditRemain;

- (void)sendMessageWithUsername:(NSString *)username password:(NSString *)password msisdn:(NSString *)msisdn message:(NSString *)message sender:(NSString *)sender scheduledDelivery:(NSString *)scheduledDelivery delegate:(id)delegate
{
    NSURL *url = [NSURL URLWithString:@"http://www.thaibulksms.com/sms_api.php"];
    
    NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:url];
    NSString *string = [[NSString alloc] initWithFormat:@"username=%@&password=%@&msisdn=%@&message=%@&sender=%@&ScheduledDelivery=%@", username, password, msisdn, [message stringByReplacingOccurrencesOfString:@"&" withString:@"%26"], sender, scheduledDelivery];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[string dataUsingEncoding:NSUTF8StringEncoding]];
    
    urlConnectionGetCreditRemain = nil;
    
    urlConnectionSendMessage = [[NSURLConnection alloc] initWithRequest:urlRequest delegate:delegate];
    [urlConnectionSendMessage start];
}

- (void)getCreditRemainWithUsername:(NSString *)username password:(NSString *)password OfSMSType:(NSString *)smsType delegate:(id)delegate
{
    NSURL *url = [NSURL URLWithString:@"http://www.thaibulksms.com/sms_api.php"];
    
    NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:url];
    NSString *string = [[NSString alloc] initWithFormat:@"username=%@&password=%@&tag=%@", username, password, smsType];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[string dataUsingEncoding:NSUTF8StringEncoding]];
    
    urlConnectionSendMessage = nil;
    
    urlConnectionGetCreditRemain = [[NSURLConnection alloc] initWithRequest:urlRequest delegate:delegate];
    [urlConnectionGetCreditRemain start];
}

@end
