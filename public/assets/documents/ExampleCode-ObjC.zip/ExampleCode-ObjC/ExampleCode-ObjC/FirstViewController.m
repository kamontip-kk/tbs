//
//  FirstViewController.m
//  ExampleCode-ObjC
//
//  Created by 1Moby 1Moby on 4/19/55 BE.
//  Copyright (c) 2555 1Moby. All rights reserved.
//

#import "FirstViewController.h"

@interface FirstViewController ()

@end

@implementation FirstViewController
@synthesize statusResult;
@synthesize detailResult;
@synthesize usedCreditResult;
@synthesize remainCreditResult;
@synthesize usernameTextField;
@synthesize passwordTextField;
@synthesize msisdnTextField;
@synthesize messageTextField;
@synthesize senderTextField;
@synthesize scheduledDeliveryTextField;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Send Message", @"First");
        self.tabBarItem.image = [UIImage imageNamed:@"first"];
    }
    return self;
}
							
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    thaiBulkSMSAPI = [[ThaiBulkSMSAPI alloc] init];
    
    scheduledDeliveryDatePicker = [[UIDatePicker alloc] init];
    [scheduledDeliveryTextField setInputView:scheduledDeliveryDatePicker];
    [scheduledDeliveryTextField setDelegate:self];
}

- (void)viewDidUnload
{
    [self setUsernameTextField:nil];
    [self setPasswordTextField:nil];
    [self setMsisdnTextField:nil];
    [self setMessageTextField:nil];
    [self setSenderTextField:nil];
    [self setScheduledDeliveryTextField:nil];
    [self setStatusResult:nil];
    [self setDetailResult:nil];
    [self setUsedCreditResult:nil];
    [self setRemainCreditResult:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)sendMessage:(id)sender
{
    countUsedCredit = 0;
    
    [detailResult setText:nil];
    
    [thaiBulkSMSAPI sendMessageWithUsername:usernameTextField.text password:passwordTextField.text msisdn:msisdnTextField.text message:messageTextField.text sender:senderTextField.text scheduledDelivery:scheduledDeliveryTextField.text delegate:self];
}

- (void)connection:(NSURLConnection *)theConnection didReceiveResponse:(NSURLResponse *)response
{
    assert(theConnection == thaiBulkSMSAPI.urlConnectionSendMessage);
    
    NSHTTPURLResponse * httpResponse;
    httpResponse = (NSHTTPURLResponse *) response;
    assert( [httpResponse isKindOfClass:[NSHTTPURLResponse class]] );
    
    if ((httpResponse.statusCode / 100) != 2) {
        NSLog(@"HTTP error %zd", (ssize_t) httpResponse.statusCode);
    } else {
        NSLog(@"Response OK.");
    }    
}

- (void)connection:(NSURLConnection *)theConnection didReceiveData:(NSData *)data
{
    assert(theConnection == thaiBulkSMSAPI.urlConnectionSendMessage);
    
    NSString *receivedString = [[NSString alloc] initWithBytes:[data bytes] length:[data length] encoding:NSUTF8StringEncoding];
    
    NSLog(@"receivedString:\n%@", receivedString);
    
    NSXMLParser *xmlParser = [[NSXMLParser alloc] initWithData:data];
    [xmlParser setDelegate:self];
    [xmlParser parse];
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qualifiedName attributes:(NSDictionary *)attributeDict
{
    if ( [elementName isEqualToString:@"Status"])
    {
        if (!status)
            status = [[NSMutableString alloc] init];
        return;
    }
    
    // Succeeded elements
    if ( [elementName isEqualToString:@"Msisdn"])
    {
        if (!msisdnXML)
            msisdnXML = [[NSMutableString alloc] init];
        return;
    }
    
    if ( [elementName isEqualToString:@"Transaction"])
    {
        if (!transaction)
            transaction = [[NSMutableString alloc] init];
        return;
    }
    
    if ( [elementName isEqualToString:@"UsedCredit"])
    {
        if (!usedCredit)
            usedCredit = [[NSMutableString alloc] init];
        return;
    }
    
    if ( [elementName isEqualToString:@"RemainCredit"])
    {
        if (!remainCredit)
            remainCredit = [[NSMutableString alloc] init];
        return;
    }
    
    // Failed element
    if ( [elementName isEqualToString:@"Detail"])
    {
        if (!detail)
            detail = [[NSMutableString alloc] init];
        return;
        
    }
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    tempString = [[NSMutableString alloc] init];
    [tempString appendString:string];
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    if ( [elementName isEqualToString:@"Status"])
    {
        status = tempString;
        [statusResult setText:status];
    }
    
    // Succeeded elements
    if ( [elementName isEqualToString:@"Msisdn"])
    {
        msisdnXML = tempString;
    }
    
    if ( [elementName isEqualToString:@"Transaction"])
    {
        transaction = tempString;
    }
    
    if ( [elementName isEqualToString:@"UsedCredit"])
    {
        usedCredit = tempString;
        countUsedCredit = countUsedCredit+[usedCredit intValue];
        [usedCreditResult setText:[[NSString alloc] initWithFormat:@"%d", countUsedCredit]];
    }
    
    if ( [elementName isEqualToString:@"RemainCredit"])
    {
        remainCredit = tempString;
        [remainCreditResult setText:remainCredit];
    }
    
    // Failed element
    if ( [elementName isEqualToString:@"Detail"])
    {
        detail = tempString;
        [detailResult setText:detail];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if (textField == scheduledDeliveryTextField)
    {
        NSDateFormatter *scheduledDeliveryDateFormatter = [[NSDateFormatter alloc] init];
        [scheduledDeliveryDateFormatter setDateFormat:@"yyMMddHHmm"];
        [scheduledDeliveryDateFormatter setLocale:[[NSLocale alloc] initWithLocaleIdentifier:@"en_US"]];
        [scheduledDeliveryTextField setText:[scheduledDeliveryDateFormatter stringFromDate:scheduledDeliveryDatePicker.date]];
    }
}

- (IBAction)backgroundTap:(id)sender
{
    [usernameTextField resignFirstResponder];
    [passwordTextField resignFirstResponder];
    [msisdnTextField resignFirstResponder];
    [messageTextField resignFirstResponder];
    [senderTextField resignFirstResponder];
    [scheduledDeliveryTextField resignFirstResponder];
}

@end
