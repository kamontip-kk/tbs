//
//  FirstViewController.h
//  ExampleCode-ObjC
//
//  Created by 1Moby 1Moby on 4/19/55 BE.
//  Copyright (c) 2555 1Moby. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ThaiBulkSMSAPI.h"

@interface FirstViewController : UIViewController <NSXMLParserDelegate, UITextFieldDelegate> {
    ThaiBulkSMSAPI *thaiBulkSMSAPI;
    
    NSMutableString *tempString;
    
    NSMutableString *status;
    NSMutableString *msisdnXML;
    NSMutableString *transaction;
    NSMutableString *usedCredit;
    NSMutableString *remainCredit;
    NSMutableString *detail;
    
    UIDatePicker *scheduledDeliveryDatePicker;
    
    NSUInteger countUsedCredit;
}
@property (unsafe_unretained, nonatomic) IBOutlet UITextField *usernameTextField;
@property (unsafe_unretained, nonatomic) IBOutlet UITextField *passwordTextField;
@property (unsafe_unretained, nonatomic) IBOutlet UITextField *msisdnTextField;
@property (unsafe_unretained, nonatomic) IBOutlet UITextField *messageTextField;
@property (unsafe_unretained, nonatomic) IBOutlet UITextField *senderTextField;
@property (unsafe_unretained, nonatomic) IBOutlet UITextField *scheduledDeliveryTextField;

- (IBAction)sendMessage:(id)sender;

@property (unsafe_unretained, nonatomic) IBOutlet UILabel *statusResult;
@property (unsafe_unretained, nonatomic) IBOutlet UILabel *detailResult;
@property (unsafe_unretained, nonatomic) IBOutlet UILabel *usedCreditResult;
@property (unsafe_unretained, nonatomic) IBOutlet UILabel *remainCreditResult;

- (IBAction)backgroundTap:(id)sender;

@end
