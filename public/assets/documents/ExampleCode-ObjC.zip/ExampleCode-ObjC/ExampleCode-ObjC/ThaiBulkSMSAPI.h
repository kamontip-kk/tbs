//
//  ThaiBulkSMSAPI.h
//  TBSAPIObjectiveC
//
//  Created by 1Moby 1Moby on 4/18/55 BE.
//  Copyright (c) 2555 1Moby. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ThaiBulkSMSAPI : NSObject <NSXMLParserDelegate> {
    NSURLConnection *urlConnectionSendMessage;
    NSURLConnection *urlConnectionGetCreditRemain;
}

@property (nonatomic, strong) NSURLConnection *urlConnectionSendMessage;
@property (nonatomic, strong) NSURLConnection *urlConnectionGetCreditRemain;

- (void)sendMessageWithUsername:(NSString *)username password:(NSString *)password msisdn:(NSString *)msisdn message:(NSString *)message sender:(NSString *)sender scheduledDelivery:(NSString *)scheduledDelivery delegate:(id)delegate;

- (void)getCreditRemainWithUsername:(NSString *)username password:(NSString *)password OfSMSType:(NSString *)smsType delegate:(id)delegate;

@end
