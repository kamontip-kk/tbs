//
//  SecondViewController.m
//  ExampleCode-ObjC
//
//  Created by 1Moby 1Moby on 4/19/55 BE.
//  Copyright (c) 2555 1Moby. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController
@synthesize remainCreditResult;
@synthesize statusResult;
@synthesize detailResult;
@synthesize usernameTextField;
@synthesize passwordTextField;
@synthesize smsTypeSegmentedControl;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Get Credit Remain", @"Second");
        self.tabBarItem.image = [UIImage imageNamed:@"second"];
    }
    return self;
}
							
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    thaiBulkSMSAPI = [[ThaiBulkSMSAPI alloc] init];
}

- (void)viewDidUnload
{
    [self setSmsTypeSegmentedControl:nil];
    [self setRemainCreditResult:nil];
    [self setUsernameTextField:nil];
    [self setPasswordTextField:nil];
    [self setStatusResult:nil];
    [self setDetailResult:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)getCreditRemain:(id)sender
{
    [statusResult setText:nil];
    [detailResult setText:nil];
    
    NSString *smsType = [[NSString alloc] init];
    if (smsTypeSegmentedControl.selectedSegmentIndex == 0)
    {
        smsType = @"credit_remain";
    }
    else if (smsTypeSegmentedControl.selectedSegmentIndex == 1)
    {
        smsType = @"credit_remain_premium";
    }
    
    [thaiBulkSMSAPI getCreditRemainWithUsername:usernameTextField.text password:passwordTextField.text OfSMSType:smsType delegate:self];
}

- (void)connection:(NSURLConnection *)theConnection didReceiveResponse:(NSURLResponse *)response
{
    assert(theConnection == thaiBulkSMSAPI.urlConnectionGetCreditRemain);
    
    NSHTTPURLResponse * httpResponse;
    httpResponse = (NSHTTPURLResponse *) response;
    assert( [httpResponse isKindOfClass:[NSHTTPURLResponse class]] );
    
    if ((httpResponse.statusCode / 100) != 2) {
        NSLog(@"HTTP error %zd", (ssize_t) httpResponse.statusCode);
    } else {
        NSLog(@"Response OK.");
    }    
}

- (void)connection:(NSURLConnection *)theConnection didReceiveData:(NSData *)data
{  
    assert(theConnection == thaiBulkSMSAPI.urlConnectionGetCreditRemain);

    NSString *receivedString = [[NSString alloc] initWithBytes:[data bytes] length:[data length] encoding:NSUTF8StringEncoding];
    
    NSLog(@"receivedString:\n%@", receivedString);
    
    if ([receivedString rangeOfString:@"<SMS>"].location == NSNotFound)
    {
        [remainCreditResult setText:receivedString];
    }
    
    NSXMLParser *xmlParser = [[NSXMLParser alloc] initWithData:data];
    [xmlParser setDelegate:self];
    [xmlParser parse];
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qualifiedName attributes:(NSDictionary *)attributeDict
{
    if ( [elementName isEqualToString:@"Status"])
    {
        if (!status)
            status = [[NSMutableString alloc] init];
        return;
    }
    
    if ( [elementName isEqualToString:@"Detail"])
    {
        if (!detail)
            detail = [[NSMutableString alloc] init];
        return;
        
    }
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    tempString = [[NSMutableString alloc] init];
    [tempString appendString:string];
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    if ( [elementName isEqualToString:@"Status"])
    {
        status = tempString;
        [statusResult setText:status];
    }

    if ( [elementName isEqualToString:@"Detail"])
    {
        detail = tempString;
        [detailResult setText:detail];
    }
}

- (IBAction)backgroundTap:(id)sender
{
    [usernameTextField resignFirstResponder];
    [passwordTextField resignFirstResponder];
}

@end
