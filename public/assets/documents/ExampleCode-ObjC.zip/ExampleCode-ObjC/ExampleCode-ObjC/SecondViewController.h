//
//  SecondViewController.h
//  ExampleCode-ObjC
//
//  Created by 1Moby 1Moby on 4/19/55 BE.
//  Copyright (c) 2555 1Moby. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ThaiBulkSMSAPI.h"

@interface SecondViewController : UIViewController <NSXMLParserDelegate> {
    ThaiBulkSMSAPI *thaiBulkSMSAPI;
    
    NSMutableString *tempString;
    
    NSMutableString *status;
    NSMutableString *detail;
}

@property (unsafe_unretained, nonatomic) IBOutlet UITextField *usernameTextField;
@property (unsafe_unretained, nonatomic) IBOutlet UITextField *passwordTextField;
@property (unsafe_unretained, nonatomic) IBOutlet UISegmentedControl *smsTypeSegmentedControl;

- (IBAction)getCreditRemain:(id)sender;

@property (unsafe_unretained, nonatomic) IBOutlet UILabel *remainCreditResult;
@property (unsafe_unretained, nonatomic) IBOutlet UILabel *statusResult;
@property (unsafe_unretained, nonatomic) IBOutlet UILabel *detailResult;

- (IBAction)backgroundTap:(id)sender;

@end
