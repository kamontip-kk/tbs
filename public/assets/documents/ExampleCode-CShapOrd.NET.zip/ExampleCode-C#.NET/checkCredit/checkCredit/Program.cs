﻿using System;
using System.Net;
using System.Web;
using System.Collections;
using System.IO;
using System.Xml;

namespace checkCredit
{

    class WebPostRequest
    {
        WebRequest theRequest;
        HttpWebResponse theResponse;
        ArrayList theQueryData;

        public WebPostRequest(string url)
        {
            System.Net.ServicePointManager.Expect100Continue = false;
            theRequest = WebRequest.Create(url);
            theRequest.Method = "POST";
            theQueryData = new ArrayList();
        }

        public void Add(string key, string value)
        {
            theQueryData.Add(String.Format("{0}={1}", key, value));
        }

        public string GetResponse()
        {
            // Set the encoding type
            theRequest.ContentType = "application/x-www-form-urlencoded";

            // Build a string containing all the parameters
            string Parameters = String.Join("&", (String[])theQueryData.ToArray(typeof(string)));
            theRequest.ContentLength = Parameters.Length;

            // We write the parameters into the request
            StreamWriter sw = new StreamWriter(theRequest.GetRequestStream());
            sw.Write(Parameters);
            sw.Close();

            // Execute the query
            theResponse = (HttpWebResponse)theRequest.GetResponse();
            StreamReader sr = new StreamReader(theResponse.GetResponseStream());
            return sr.ReadToEnd();
        }

    }

    class MainClass
    {
        public static void Main(string[] args)
        {
            WebPostRequest myPost = new WebPostRequest("http://www.thaibulksms.com/sms_api_test.php");
            myPost.Add("username", "Your Username");
            myPost.Add("password", "Your Password");
            myPost.Add("tag", "credit_remain"); // credit_remain = standard or credit_remain_premium = premium

            try
            {
                string Str = myPost.GetResponse().Trim();
                double Num;
                bool isNum = double.TryParse(Str, out Num);
                if (isNum)
                {
                    Console.WriteLine("Credit Remain " + Str + " Credit");
                }
                else
                {
                    XmlDocument xml = new XmlDocument();
                    xml.LoadXml(Str);
                    XmlNodeList xnList = xml.SelectNodes("SMS");
                    int count_node = xnList.Count;
                    //Console.WriteLine(count_node);
                    if (count_node > 0)
                    {
                        foreach (XmlNode xn in xnList)
                        {
                            string status = xn["Status"].InnerText;
                            string status_detail = xn["Detail"].InnerText;
                            Console.WriteLine("Error: {0}", status_detail);
                        }
                    }
                }

                Console.WriteLine("Press any key to end...");
                Console.Read();
            }
            catch
            {
                Console.WriteLine("Error to sending");
                Console.WriteLine("Press any key to end...");
                Console.Read();
            }
        }
    }
}