//
//  test.c
//  ExampleCode-C
//
//  Created by 1Moby 1Moby on 4/23/55 BE.
//  Copyright (c) 2555 1Moby. All rights reserved.
//

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "ThaiBulkSMSAPI.h"

#include "expat.h"

#if defined(__amigaos__) && defined(__USE_INLINE__)
#include <proto/expat.h>
#endif

#ifdef XML_LARGE_SIZE
#if defined(XML_USE_MSC_EXTENSIONS) && _MSC_VER < 1400
#define XML_FMT_INT_MOD "I64"
#else
#define XML_FMT_INT_MOD "ll"
#endif
#else
#define XML_FMT_INT_MOD "l"
#endif

static void XMLCALL
startElement(void *userData, const char *name, const char **atts)
{
    int i;
    int *depthPtr = (int *)userData;
    
    printf("%s", name);
    
    *depthPtr += 1;
}

static void XMLCALL
endElement(void *userData, const char *name)
{
    int *depthPtr = (int *)userData;
    *depthPtr -= 1;
}

static char    *last_content;

void
handle_data(void *data, const char *content, int length)
{
    char           *tmp = malloc(length);
    strncpy(tmp, content, length);
    tmp[length] = '\0';
    data = (void *) tmp;
    last_content = tmp;
    
    printf(" %s", last_content);
}

int main(int argc, char **argv)
{
    // Handling for lack of arguments
    if (argc == 1)
    {
        argv[1] = "";
        argv[2] = "";
        argv[3] = "";
    }
    else if (argc == 2)
    {
        argv[2] = "";
        argv[3] = "";
    }
    else if (argc == 3)
    {
        argv[3] = "credit_remain";
    }
    
    Data newData = getCreditRemain(argv[1], argv[2], argv[3]);
//    printf ("Status Code: %ld\n", newData.statusCode);
//    printf ("Data: %s\n", newData.data);
    
    if (newData.statusCode == 200)
    {
        int isNumeric = atoi(newData.data);
        if (isNumeric != 0)
        {
            printf ("Remain Credit(s): %s\n", newData.data);
        }
        else
        {
            XML_Parser parser = XML_ParserCreate(NULL);
            int depth = 0;
            XML_SetUserData(parser, &depth);
            XML_SetElementHandler(parser, startElement, endElement);
            XML_SetCharacterDataHandler(parser, handle_data); // For getting data, not elements or attributes
            if (XML_Parse(parser, newData.data, strlen(newData.data), XML_TRUE) == XML_STATUS_ERROR)
            {
                printf("Error: %s\n", XML_ErrorString(XML_GetErrorCode(parser)));
                return 1;
            }
            XML_ParserFree(parser);
        }
    }
    else
    {
        printf("Error: %ld\n", newData.statusCode);
    }
    
    return 0;
}
