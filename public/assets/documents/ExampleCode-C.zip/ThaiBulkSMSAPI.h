//
//  ThaiBulkSMSAPI.h
//  ExampleCode-C
//
//  Created by 1Moby 1Moby on 4/23/55 BE.
//  Copyright (c) 2555 1Moby. All rights reserved.
//

#ifndef ExampleCode_C_ThaiBulkSMSAPI_h
#define ExampleCode_C_ThaiBulkSMSAPI_h

typedef struct {
    long statusCode;
    char *data;
} Data;

Data sendMessage (char *username, char *password, char *msisdn, char *message, char *sender, char *ScheduledDelivery);

Data getCreditRemain (char *username, char *password, char *tag);

#endif
