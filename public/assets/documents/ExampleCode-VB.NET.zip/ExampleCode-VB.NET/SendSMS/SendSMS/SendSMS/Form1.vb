﻿Imports System
Imports System.Text
Imports System.Net
Imports System.Web
Imports System.IO
Imports System.Xml

Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If username.Text.Length = 0 Or password.Text.Length = 0 Or msisdn.Text.Length = 0 Or message.Text.Length = 0 Then
            MessageBox.Show("Please Check Your Data")
        Else
            If senderName.Text.Length = 0 Then
                senderName.Text = "THAIBULKSMS"
            End If

            If force.Text.Length = 0 Then
                force.Text = "standard"
            End If

            Dim ScheduledDeliveryCheck = Boolean.Parse(DatePicker.Checked.ToString())
            Dim Scheduled As String
            If ScheduledDeliveryCheck = True Then
                Dim dtDate As String = DatePicker.Text
                Dim dt As Array = dtDate.Split("-")
                Dim year As Integer = dt(0)
                Dim yearCheck As Integer = Int(Int32.Parse(year))
                Dim dtTime As String = TimePicker.Text
                Dim dm As Array = dtTime.Split(":")
                'MessageBox.Show(yearCheck.ToString())
                If yearCheck > 2500 Then
                    yearCheck = yearCheck - 543
                    Dim yearChecks As String = yearCheck.ToString().Substring(2)
                    Scheduled = yearChecks + "" + dt(1) + "" + dt(2) + "" + dm(0) + "" + dm(1)
                Else
                    Dim yearChecks As String = yearCheck.ToString().Substring(2)
                    Scheduled = yearChecks + "" + dt(1) + "" + dt(2) + "" + dm(0) + "" + dm(1)
                End If
                'MessageBox.Show(yearCheck.ToString());

            Else
                Scheduled = ""
            End If

            System.Net.ServicePointManager.Expect100Continue = False
            Dim request As WebRequest = WebRequest.Create("http://www.thaibulksms.com/sms_api_test.php")
            request.Method = "POST"
            Dim postData As String = "username=" + System.Uri.EscapeUriString(username.Text) +
                    "&password=" + System.Uri.EscapeUriString(password.Text) +
                    "&msisdn=" + System.Uri.EscapeUriString(msisdn.Text) +
                    "&message=" + System.Uri.EscapeUriString(message.Text) +
                    "&sender=" + System.Uri.EscapeUriString(senderName.Text) +
                    "&ScheduledDelivery=" + System.Uri.EscapeUriString(Scheduled.ToString()) +
                    "&force=" + System.Uri.EscapeUriString(force.Text)
            Dim byteArray As Byte() = Encoding.UTF8.GetBytes(postData)
            request.ContentType = "application/x-www-form-urlencoded"
            request.ContentLength = byteArray.Length
            Dim dataStream As Stream = request.GetRequestStream()
            dataStream.Write(byteArray, 0, byteArray.Length)
            dataStream.Close()
            Dim response As WebResponse = request.GetResponse()
            Console.WriteLine(CType(response, HttpWebResponse).StatusDescription)
            dataStream = response.GetResponseStream()
            Dim reader As New StreamReader(dataStream)
            Dim responseFromServer As String = reader.ReadToEnd()
            Console.WriteLine(responseFromServer)
            reader.Close()
            dataStream.Close()
            response.Close()

            'MessageBox.Show(responseFromServer)

            Dim returnData As String = responseFromServer
            Dim xml As New Xml.XmlDocument()
            Xml.LoadXml(returnData)
            Dim xnList = xml.SelectNodes("/SMS")
            Dim count_node As Integer = xnList.Count
            If count_node > 0 Then
                For Each xn In xnList
                    Dim xnSubList = xml.SelectNodes("/SMS/QUEUE")
                    Dim countSubNode As Integer = xnSubList.Count
                    If countSubNode > 0 Then
                        For Each xnSub In xnSubList
                            If xnSub("Status").InnerText.ToString() = "1" Then
                                Dim msisdnReturn As String = xnSub("Msisdn").InnerText
                                Dim useCredit As String = xnSub("UsedCredit").InnerText
                                Dim creditRemain As String = xnSub("RemainCredit").InnerText
                                MessageBox.Show("Send SMS to " + msisdnReturn + " Success.Use credit " + useCredit + " credit, Credit Remain " + creditRemain + " Credit")
                            Else
                                Dim sub_status_detail As String = xnSub("Detail").InnerText
                                MessageBox.Show("Error: " + sub_status_detail)
                            End If
                        Next
                    Else
                        If xn("Status").InnerText = "0" Then
                            Dim status_detail As String = xn("Detail").InnerText
                            MessageBox.Show("Error: " + status_detail)
                        Else
                            MessageBox.Show("Error: Can not read data(Not XML Format)")
                        End If
                    End If
                Next
            Else
                MessageBox.Show("Error: Can not read data(Not XML Format)")
            End If
        End If
    End Sub

    Private Sub DatePicker_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DatePicker.ValueChanged
        Dim ScheduledDeliveryCheck = Boolean.Parse(DatePicker.Checked.ToString())
        If ScheduledDeliveryCheck = True Then
            TimePicker.Enabled = True
        Else
            TimePicker.Enabled = False
        End If
    End Sub
End Class
