﻿Imports System
Imports System.Text
Imports System.Net
Imports System.Web
Imports System.IO
Imports System.Xml

Public Class Form1

    Private Sub submit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles submit.Click
        If username.Text.Length = 0 Or password.Text.Length = 0 Or CreditType.Text.Length = 0 Then
            MessageBox.Show("Please Check Your Data")
        Else
            'Try
            System.Net.ServicePointManager.Expect100Continue = False
            Dim request As WebRequest = WebRequest.Create("http://www.thaibulksms.com/sms_api_test.php")
            request.Method = "POST"
            Dim postData As String = "username=" + System.Uri.EscapeUriString(username.Text) +
                    "&password=" + System.Uri.EscapeUriString(password.Text) +
                    "&tag=" + System.Uri.EscapeUriString(CreditType.Text)
            Dim byteArray As Byte() = Encoding.UTF8.GetBytes(postData)
            request.ContentType = "application/x-www-form-urlencoded"
            request.ContentLength = byteArray.Length
            Dim dataStream As Stream = request.GetRequestStream()
            dataStream.Write(byteArray, 0, byteArray.Length)
            dataStream.Close()
            Dim response As WebResponse = request.GetResponse()
            Console.WriteLine(CType(response, HttpWebResponse).StatusDescription)
            dataStream = response.GetResponseStream()
            Dim reader As New StreamReader(dataStream)
            Dim responseFromServer As String = reader.ReadToEnd()
            Console.WriteLine(responseFromServer)
            reader.Close()
            dataStream.Close()
            response.Close()

            'MessageBox.Show(responseFromServer)

            'Try
            Dim Str As String = responseFromServer.Trim()
            Dim Num As Integer
            If Integer.TryParse(Str, Num) Then
                MessageBox.Show("Credit Remain " + Str + " Credit")
            Else
                Dim xml As New Xml.XmlDocument()
                xml.LoadXml(Str)
                Dim xnList = xml.SelectNodes("SMS")
                Dim countNode As Integer = xnList.Count
                'MessageBox.Show("CountNoed" + countNode.ToString())
                If countNode > 0 Then
                    For Each xn In xnList
                        Dim status As String = xn.ChildNodes.Item(0).InnerText
                        If status = 0 Then
                            Dim status_detail As String = xn.ChildNodes.Item(1).InnerText
                            MessageBox.Show("Error: " + status_detail.ToString())
                        End If
                    Next
                Else
                    MessageBox.Show("Error to sending2")
                End If
            End If
            'Catch
            'MessageBox.Show("Error to sending1")
            'End Try
        End If
    End Sub
End Class
