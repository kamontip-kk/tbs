﻿using System;
using RestSharp;
using RestSharp.Authenticators;

namespace send_otp
{
    class Program
    {
        private static IRestRequest CreateRequestBody(string phoneNumber)
        {

            if (String.IsNullOrEmpty(phoneNumber))
            {
                throw new ArgumentException("Phone Number is missing");
            }
            var request = new RestRequest(Method.POST);
            request.AddJsonBody(new { msisdn = phoneNumber });

            return request;
        }

        private static HttpBasicAuthenticator CreateBasicAuth(string apiKey, string secretKey)
        {
            if (String.IsNullOrEmpty(apiKey) || String.IsNullOrEmpty(secretKey))
            {
                throw new ArgumentException("Api Ket or Secret Key is missing");
            }
            var authen = new HttpBasicAuthenticator(apiKey, secretKey);

            return authen;
        }

        static void Main(string[] args)
        {
            var client = new RestClient("https://otp.thaibulksms.com/v1/otp/request");
            client.Authenticator = CreateBasicAuth("%API_KEY%", "%SECRET_KEY%");
            client.Timeout = -1;
            var request = CreateRequestBody("%PHONE_NUMBER%");

            IRestResponse response = client.Execute(request);

            Console.WriteLine(response.Content);


        }

    }
}
