﻿using System;
using RestSharp;
using RestSharp.Authenticators;

namespace sms
{
    class Program
    {
        private static IRestRequest CreateRequestBody(string phoneNumber, string message, string sender = "", string scheduled_delivery = "", string force = "")
        {

            if (String.IsNullOrEmpty(phoneNumber) || String.IsNullOrEmpty(message))
            {
                throw new ArgumentException("Phone Number or Message is missing");
            }
            var request = new RestRequest(Method.POST);
            request.AddJsonBody(new { msisdn = phoneNumber, message = message, sender = "", scheduled_delivery = "", force = "" });

            return request;
        }

        private static HttpBasicAuthenticator CreateBasicAuth(string apiKey, string secretKey)
        {
            if (String.IsNullOrEmpty(apiKey) || String.IsNullOrEmpty(secretKey))
            {
                throw new ArgumentException("Api Ket or Secret Key is missing");
            }
            var authen = new HttpBasicAuthenticator(apiKey, secretKey);

            return authen;
        }

        static void Main(string[] args)
        {
            var client = new RestClient("https://api-v2.thaibulksms.com/sms");
            client.Authenticator = CreateBasicAuth("%API_KEY%", "%SECRET_KEY%");
            client.Timeout = -1;
            var request = CreateRequestBody("%PHONE_NUMBER%", "%MESSAGE%");

            IRestResponse response = client.Execute(request);

            Console.WriteLine(response.Content);


        }

    }
}
