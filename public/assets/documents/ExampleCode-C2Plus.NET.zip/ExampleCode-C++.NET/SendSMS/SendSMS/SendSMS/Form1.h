#pragma once

namespace SendSMS {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	//using namespace System::Boolean;
	using namespace System::Collections::Generic;
	using namespace System::ComponentModel;
	using namespace System::Linq;
	using namespace System::Text;
	using namespace System::Net;
	using namespace System::Web;
	using namespace System::Collections;
	using namespace System::IO;
	using namespace System::Xml;
	using namespace System::Globalization;
	using namespace System::Threading;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  username;
	private: System::Windows::Forms::TextBox^  password;
	protected: 

	protected: 

	private: System::Windows::Forms::TextBox^  msisdn;
	private: System::Windows::Forms::ComboBox^  senderName;
	private: System::Windows::Forms::ComboBox^  force;
	private: System::Windows::Forms::DateTimePicker^  datePicker;
	private: System::Windows::Forms::DateTimePicker^  TimePicker;
	private: System::Windows::Forms::RichTextBox^  message;






	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Label^  label7;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->username = (gcnew System::Windows::Forms::TextBox());
			this->password = (gcnew System::Windows::Forms::TextBox());
			this->msisdn = (gcnew System::Windows::Forms::TextBox());
			this->senderName = (gcnew System::Windows::Forms::ComboBox());
			this->force = (gcnew System::Windows::Forms::ComboBox());
			this->datePicker = (gcnew System::Windows::Forms::DateTimePicker());
			this->TimePicker = (gcnew System::Windows::Forms::DateTimePicker());
			this->message = (gcnew System::Windows::Forms::RichTextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// username
			// 
			this->username->Location = System::Drawing::Point(116, 41);
			this->username->Name = L"username";
			this->username->Size = System::Drawing::Size(100, 20);
			this->username->TabIndex = 0;
			// 
			// password
			// 
			this->password->Location = System::Drawing::Point(116, 68);
			this->password->Name = L"password";
			this->password->Size = System::Drawing::Size(100, 20);
			this->password->TabIndex = 1;
			// 
			// msisdn
			// 
			this->msisdn->Location = System::Drawing::Point(116, 95);
			this->msisdn->Name = L"msisdn";
			this->msisdn->Size = System::Drawing::Size(100, 20);
			this->msisdn->TabIndex = 2;
			// 
			// senderName
			// 
			this->senderName->FormattingEnabled = true;
			this->senderName->Items->AddRange(gcnew cli::array< System::Object^  >(1) {L"THAIBULKSMS"});
			this->senderName->Location = System::Drawing::Point(116, 122);
			this->senderName->Name = L"senderName";
			this->senderName->Size = System::Drawing::Size(121, 21);
			this->senderName->TabIndex = 3;
			this->senderName->Text = L"THAIBULKSMS";
			// 
			// force
			// 
			this->force->FormattingEnabled = true;
			this->force->Items->AddRange(gcnew cli::array< System::Object^  >(2) {L"standard", L"premium"});
			this->force->Location = System::Drawing::Point(116, 150);
			this->force->Name = L"force";
			this->force->Size = System::Drawing::Size(121, 21);
			this->force->TabIndex = 4;
			this->force->Text = L"standard";
			// 
			// datePicker
			// 
			this->datePicker->Checked = false;
			this->datePicker->CustomFormat = L"yyyy-MM-dd";
			this->datePicker->Format = System::Windows::Forms::DateTimePickerFormat::Custom;
			this->datePicker->Location = System::Drawing::Point(116, 178);
			this->datePicker->Name = L"datePicker";
			this->datePicker->ShowCheckBox = true;
			this->datePicker->Size = System::Drawing::Size(200, 20);
			this->datePicker->TabIndex = 5;
			this->datePicker->ValueChanged += gcnew System::EventHandler(this, &Form1::datePicker_ValueChanged);
			// 
			// TimePicker
			// 
			this->TimePicker->CustomFormat = L"HH:mm";
			this->TimePicker->Enabled = false;
			this->TimePicker->Format = System::Windows::Forms::DateTimePickerFormat::Custom;
			this->TimePicker->Location = System::Drawing::Point(116, 205);
			this->TimePicker->Name = L"TimePicker";
			this->TimePicker->ShowUpDown = true;
			this->TimePicker->Size = System::Drawing::Size(200, 20);
			this->TimePicker->TabIndex = 6;
			// 
			// message
			// 
			this->message->Location = System::Drawing::Point(116, 232);
			this->message->Name = L"message";
			this->message->Size = System::Drawing::Size(258, 96);
			this->message->TabIndex = 7;
			this->message->Text = L"";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(116, 335);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 8;
			this->button1->Text = L"Submit";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(12, 44);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(55, 13);
			this->label1->TabIndex = 9;
			this->label1->Text = L"Username";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(12, 71);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(53, 13);
			this->label2->TabIndex = 10;
			this->label2->Text = L"Password";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(12, 98);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(78, 13);
			this->label3->TabIndex = 11;
			this->label3->Text = L"Phone Number";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(13, 125);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(72, 13);
			this->label4->TabIndex = 12;
			this->label4->Text = L"Sender Name";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(13, 153);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(61, 13);
			this->label5->TabIndex = 13;
			this->label5->Text = L"Credit Type";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(13, 184);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(96, 13);
			this->label6->TabIndex = 14;
			this->label6->Text = L"ScheduledDelivery";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(13, 235);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(50, 13);
			this->label7->TabIndex = 15;
			this->label7->Text = L"Message";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(513, 454);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->message);
			this->Controls->Add(this->TimePicker);
			this->Controls->Add(this->datePicker);
			this->Controls->Add(this->force);
			this->Controls->Add(this->senderName);
			this->Controls->Add(this->msisdn);
			this->Controls->Add(this->password);
			this->Controls->Add(this->username);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
		String^ username = this->username->Text;
		String^ password = this->password->Text;
		String^ msisdn = this->msisdn->Text;
		String^ senderName = this->senderName->Text;
		String^ force = this->force->Text;
		String^ message = this->message->Text;

		//MessageBox::Show(username->Text->ToString());
		if (username->Length == 0 || password->Length == 0 || msisdn->Length == 0 || message->Length == 0)
        {
            MessageBox::Show("Please Check Your Data");
        }
        else
        {

			if (senderName == "")
			{
				senderName = "THAIBULKSMS";
			}

			if (force == "")
			{
				force = "standard"; 
			}

			String^ Scheduled;
			//char *dt[3];
			bool^ ScheduledDeliveryCheck = datePicker->Checked;
			if ((bool)ScheduledDeliveryCheck == true)
			{
				String^ dtYear = datePicker->Text;
				array<wchar_t>^ chars = {'-'};
				array<String^>^ dt = dtYear->Split(chars);
				String^ year = dt[0];
				int yearCheck = Int32::Parse(year);
				String^ dtHour = TimePicker->Text;
				array<wchar_t>^ charsHour = {':'};
				array<String^>^ dm = dtHour->Split(charsHour);
				if (yearCheck > 2500)
				{
					yearCheck = yearCheck - 543;
					String^ yearChecks = Convert::ToString(yearCheck);
					yearChecks = yearChecks->Substring(2);
					Scheduled = yearChecks + "" + dt[1] + "" + dt[2] + "" + dm[0] + "" + dm[1];
				}
				else
				{
					String^ yearChecks = Convert::ToString(yearCheck);
					yearChecks = yearChecks->Substring(2);
					Scheduled = yearChecks + "" + dt[1] + "" + dt[2] + "" + dm[0] + "" + dm[1];
				}
				//MessageBox::Show(Scheduled->ToString());
			}
			else
			{
				Scheduled = "";
			}

			String^ url = "http://www.thaibulksms.com/sms_api_test.php";
			String^ result = "";
			String^ strPost = "username=" + System::Uri::EscapeUriString(username) + 
				"&password=" + System::Uri::EscapeUriString(password) + 
				"&msisdn=" + System::Uri::EscapeUriString(msisdn) + 
				"&message=" + System::Uri::EscapeUriString(message) + 
				"&sender=" + System::Uri::EscapeUriString(senderName) + 
				"&ScheduledDelivery=" + System::Uri::EscapeUriString(Scheduled) + 
				"&force=" + System::Uri::EscapeUriString(force);
			//MessageBox::Show(Convert::ToString(strPost->Length));
			int strLength = strPost->Length;
			ServicePointManager::Expect100Continue = false;
			HttpWebRequest^ objRequest = dynamic_cast<HttpWebRequest^>(WebRequest::Create(url));
			objRequest->Method = "POST";
			objRequest->ContentLength = strLength;
			objRequest->ContentType = "application/x-www-form-urlencoded";
			//objRequest->SendChunked = true;
			StreamWriter^ myWriter = gcnew StreamWriter(objRequest->GetRequestStream());
			myWriter->Write(strPost);
			myWriter->Close();

			try
			{
				HttpWebResponse^ objResponse = dynamic_cast<HttpWebResponse^>(objRequest->GetResponse());
				StreamReader^ sr = gcnew StreamReader(objResponse->GetResponseStream());
				result = sr->ReadToEnd();
				//sr->Close();

				//MessageBox::Show(result);
				try{
					String^ returnData = result;
					XmlDocument^ xml = gcnew XmlDocument;
					//xml->Load(returnData);
					xml->LoadXml(returnData);
					XmlNodeList^ xnList = xml->SelectNodes("/SMS");
					int count_node = xnList->Count;
					if (count_node > 0)
					{
						for each (XmlNode^ xn in xnList)
						{

							XmlNodeList^ xnSubList = xml->SelectNodes("/SMS/QUEUE");
							int countSubNode = xnSubList->Count;
							if (countSubNode > 0)
							{
								for each (XmlNode^ xnSub in xnSubList)
								{
									if (xnSub["Status"]->InnerText == "1")
									{
										String^ msisdnReturn = xnSub["Msisdn"]->InnerText;
										String^ useCredit = xnSub["UsedCredit"]->InnerText;
										String^ creditRemain = xnSub["RemainCredit"]->InnerText;
										MessageBox::Show("Send SMS to " + msisdnReturn + " Success.Use credit " + useCredit + " credit, Credit Remain " + creditRemain + " Credit");
									}
									else
									{
										String^ sub_status_detail = xnSub["Detail"]->InnerText;
										MessageBox::Show("Error: " + sub_status_detail);
									}
								}
							}
							else
							{
								if (xn["Status"]->InnerText == "0")
								{
									String^ status_detail = xn["Detail"]->InnerText;
									MessageBox::Show("Error: " + status_detail);
								}
								else
								{
									MessageBox::Show("Error: Can not read data(Not XML Format)");
								}
							}
						}
					}
					else
					{
						MessageBox::Show("Error: Can not read data(Not XML Format)");
					}
				}catch(Exception^ xmlS){
					MessageBox::Show(xmlS->Message);
				}
			}
			catch (Exception^ s)
			{
				MessageBox::Show(s->Message);
			}

		}
	}
	private: System::Void datePicker_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
		bool^ ScheduledDeliveryCheck = datePicker->Checked;
        if ((bool)ScheduledDeliveryCheck == true)
        {
            TimePicker->Enabled = true;
        }
        else
        {
            TimePicker->Enabled = false;
        }
	}
};
}

