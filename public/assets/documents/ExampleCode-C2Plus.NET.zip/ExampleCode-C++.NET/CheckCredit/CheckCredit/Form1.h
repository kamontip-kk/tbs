#pragma once

namespace CheckCredit {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Collections::Generic;
	using namespace System::ComponentModel;
	using namespace System::Linq;
	using namespace System::Text;
	using namespace System::Net;
	using namespace System::Web;
	using namespace System::Collections;
	using namespace System::IO;
	using namespace System::Xml;
	using namespace System::Globalization;
	using namespace System::Threading;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  username;
	protected: 
	private: System::Windows::Forms::TextBox^  password;
	private: System::Windows::Forms::ComboBox^  tag;

	private: System::Windows::Forms::Button^  submit;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->username = (gcnew System::Windows::Forms::TextBox());
			this->password = (gcnew System::Windows::Forms::TextBox());
			this->tag = (gcnew System::Windows::Forms::ComboBox());
			this->submit = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// username
			// 
			this->username->Location = System::Drawing::Point(77, 33);
			this->username->Name = L"username";
			this->username->Size = System::Drawing::Size(100, 20);
			this->username->TabIndex = 0;
			// 
			// password
			// 
			this->password->Location = System::Drawing::Point(77, 60);
			this->password->Name = L"password";
			this->password->Size = System::Drawing::Size(100, 20);
			this->password->TabIndex = 1;
			// 
			// tag
			// 
			this->tag->FormattingEnabled = true;
			this->tag->Items->AddRange(gcnew cli::array< System::Object^  >(2) {L"credit_remain", L"credit_remain_premium"});
			this->tag->Location = System::Drawing::Point(77, 87);
			this->tag->Name = L"tag";
			this->tag->Size = System::Drawing::Size(121, 21);
			this->tag->TabIndex = 2;
			// 
			// submit
			// 
			this->submit->Location = System::Drawing::Point(77, 115);
			this->submit->Name = L"submit";
			this->submit->Size = System::Drawing::Size(75, 23);
			this->submit->TabIndex = 3;
			this->submit->Text = L"Submit";
			this->submit->UseVisualStyleBackColor = true;
			this->submit->Click += gcnew System::EventHandler(this, &Form1::submit_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(12, 36);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(55, 13);
			this->label1->TabIndex = 4;
			this->label1->Text = L"Username";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(12, 63);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(53, 13);
			this->label2->TabIndex = 5;
			this->label2->Text = L"Password";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(12, 90);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(61, 13);
			this->label3->TabIndex = 6;
			this->label3->Text = L"Credit Type";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 264);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->submit);
			this->Controls->Add(this->tag);
			this->Controls->Add(this->password);
			this->Controls->Add(this->username);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void submit_Click(System::Object^  sender, System::EventArgs^  e) {
				
				
				String^ username = this->username->Text;
				String^ password = this->password->Text;
				String^ tag = this->tag->Text;
				
				String^ url = "http://www.thaibulksms.com/sms_api_test.php";
                String^ result = "";
                String^ strPost = "username=" + System::Uri::EscapeUriString(username) + 
                    "&password=" + System::Uri::EscapeUriString(password) + 
                    "&tag=" + System::Uri::EscapeUriString(tag);
                //StreamWriter^ myWriter = "";

                int strLength = strPost->Length;
				ServicePointManager::Expect100Continue = false;
				HttpWebRequest^ objRequest = dynamic_cast<HttpWebRequest^>(WebRequest::Create(url));
				objRequest->Method = "POST";
				objRequest->ContentLength = strLength;
				objRequest->ContentType = "application/x-www-form-urlencoded";
				//objRequest->SendChunked = true;
				StreamWriter^ myWriter = gcnew StreamWriter(objRequest->GetRequestStream());
				myWriter->Write(strPost);
				myWriter->Close();

				try
				{
					HttpWebResponse^ objResponse = dynamic_cast<HttpWebResponse^>(objRequest->GetResponse());
					StreamReader^ sr = gcnew StreamReader(objResponse->GetResponseStream());
					result = sr->ReadToEnd();
					sr->Close();

					String^ Str = result->Trim();
                        
					try
					{
						XmlDocument^ xml = gcnew XmlDocument();
						xml->LoadXml(Str);
						XmlNodeList^ xnList = xml->SelectNodes("/SMS");
						//MessageBox::Show(xnList->ToString());
						int count_node = xnList->Count;
						if ((int)count_node > 0)
						{
							for each (XmlNode^ xn in xnList)
							{
								String^ status = xn["Status"]->InnerText;
								String^ status_detail = xn["Detail"]->InnerText;
								MessageBox::Show("Error: " + status_detail);
							}
						}
						else
						{
							MessageBox::Show("Error:Can not read XML");
						}
					}
					catch (Exception^ sXML)
					{
						//MessageBox::Show(sXML->Message);
						MessageBox::Show("Credit Remain " + Str + " Credit");
					}

				}
				catch (Exception^ s)
				{
					MessageBox::Show(s->Message);
				}		
			 }
};
}

